import React from "react";


function About() {
  return(
    <main id="main">
      <h1>About</h1>
      <p>More random content...</p>
    </main>
  )
}
export default About;