import React from "react";
import Trivia from "../components/Trivia";


function Home() {
  return(
    <main id="main">
      <h1>Welcome to Trivia</h1>
      <p>Here is your random question</p>
      <Trivia />
    </main>
  )
}
export default Home;