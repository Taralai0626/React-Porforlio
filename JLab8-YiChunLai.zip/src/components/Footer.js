import React from "react";

class Footer extends React.Component {
  render() {
    return(
      <footer id="footer">
        <div>&copy; HTTP5211, 2022.</div>
      </footer>
    )
  }
}
export default Footer;